# 🚀 Surge Digital Twin Platform — Notion Handbook

> 👨‍💻 Project Lead: **Hezrone Mujawo**  
> 🔍 Purpose: Smart detection of surge events in compressors using AI  
...