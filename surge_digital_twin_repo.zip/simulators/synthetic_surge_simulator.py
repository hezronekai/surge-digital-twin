
# synthetic_surge_simulator.py
import numpy as np
import pandas as pd

def generate_surge_series(length=300, surge_ratio=0.15):
    n_surge = int(length * surge_ratio)
    n_normal = length - n_surge

    normal = np.random.normal(loc=0.3, scale=0.1, size=n_normal)
    surge = np.random.normal(loc=0.85, scale=0.05, size=n_surge)

    data = np.concatenate([normal, surge])
    np.random.shuffle(data)
    df = pd.DataFrame({'Surge Score': data})
    df.to_csv("synthetic_surge.csv", index=False)
    print("✅ Generated synthetic_surge.csv")

generate_surge_series()
