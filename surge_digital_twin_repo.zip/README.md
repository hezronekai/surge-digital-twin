
# 🚀 Surge Digital Twin Platform

A full-stack, AI-powered digital twin system for surge detection in centrifugal compressors.

## 🔥 Features

- ✅ LSTM + SHAP explainable AI
- ✅ Real-time surge prediction API (FastAPI)
- ✅ Streamlit dashboard for live + historical data
- ✅ MongoDB + InfluxDB + SQLite logging
- ✅ Kafka, MQTT, Azure IoT Hub integration
- ✅ Grafana dashboards (via Docker Compose)
- ✅ Cloud deployable (Docker, GitHub Actions, Terraform)
- ✅ Alerts via Slack, Twilio
- ✅ Model export (ONNX, TFLite)

## 🧪 Quick Start (Dev)

```bash
# Clone the repo
git clone https://github.com/yourname/surge-digital-twin
cd surge-digital-twin

# Build and run locally
docker-compose up -d

# Start API
uvicorn surge_detector_api:app --reload

# Launch dashboard
streamlit run surge_dashboard.py
```

## ☁️ Cloud Deployment

Set your secrets in GitHub:
- `EC2_HOST`, `EC2_USER`, `EC2_SSH_KEY`

Then push to `main` branch for auto-deploy via GitHub Actions.

## 🛠 Tools

| Tool       | Use                       |
|------------|----------------------------|
| FastAPI    | Real-time model serving    |
| Streamlit  | UI + dashboard             |
| SHAP       | Feature explainability     |
| Kafka      | Streaming surge events     |
| Slack/SMS  | Surge alerts               |

## 📈 Grafana (via Docker)

Access Grafana at `http://localhost:3000` after:

```bash
docker-compose up -d
```

Import the dashboard JSON from `grafana_surge_dashboard.json`

---

Built with ❤️ by your AI Twin Engineering Team.
